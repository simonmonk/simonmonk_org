---
layout: "page"
title: Translations
permalink: /translations
---

Many of my books have been transalted into other languages so please search the book sellers in your country for a version in your native tongue.

![cover](/assets/images/transaltions/br.gif)
![cover](/assets/images/transaltions/ch.jpg)
![cover](/assets/images/transaltions/de.jpg)
![cover](/assets/images/transaltions/fr.jpg)
![cover](/assets/images/transaltions/ko.jpg)
![cover](/assets/images/transaltions/pl.jpg)