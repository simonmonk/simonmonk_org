---
layout: "page"
permalink: /tab-book-of-arduino
---

[Code](https://github.com/simonmonk/tab_arduino/archive/master.zip) | [Buy on Amazon](https://www.amazon.com/TAB-Book-Arduino-Projects-Electronics/dp/0071790675) | [Buy on Barnes & Noble](https://www.barnesandnoble.com/w/the-tab-book-of-arduino-projects-simon-monk/1119610146)

This book should really have been called ‘The Big Book of Arduino Projects’. Its full of a wide range or Arduino projects from LED cubes to a Geiger Counter. The projects are mostly designed around Arduino protoboard. This means you need to know how to solder to make the projects in this book.

![cover](/assets/images/cover_tab_ardu.jpg)

