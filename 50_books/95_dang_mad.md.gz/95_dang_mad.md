---
layout: "page"
permalink: /15-dangerously-mad-projects-for-the-evil-genius
---

[Code](https://github.com/simonmonk/dang_mad) | [Buy on Amazon](https://www.amazon.com/Dangerously-Mad-Projects-Evil-Genius-ebook/dp/B004YSWC0U) | [Buy on Barnes & Noble](hhttps://www.barnesandnoble.com/w/15-dangerously-mad-projects-for-the-evil-genius-simon-monk/1100641493)

This book should have been called ‘Dangerous Projects for the Evil Genius’. It includes electronic projects like a coil-gun that fires metal pellets and a trebuchet that will fling a tennis ball a good distance.

This book definitely requires parental supervision. Unless of course you are a grown-up.

![cover](/assets/images/cover_dang_mad.jpg)

