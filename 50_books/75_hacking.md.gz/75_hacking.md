---
layout: "page"
permalink: /hacking-electronics2
---

[Code](https://github.com/simonmonk/hacking2) | [Buy on Amazon](https://www.amazon.com/Hacking-Electronics-Learning-Arduino-Raspberry/dp/1260012204) | [Buy on Barnes & Noble](https://www.barnesandnoble.com/w/hacking-electronics-simon-monk/1126294989)


![cover](/assets/images/cover_hacking_2.jpg)

Hacking Electronics (second edition) takes a different an altogether much less formal approach to learning electronics than most books. You’ll get started straight-away with a soldering iron and as well as learning how to make projects from scratch, you will also learn how to modify items of consumer electronics as well as get started with Arduino and Raspberry Pi.

