---
layout: "page"
permalink: /prog-arduino-3ed
---

[Code](https://github.com/simonmonk/prog_arduino_3) | [Buy on Amazon](https://www.amazon.com/Programming-Arduino-Getting-Started-Sketches/dp/1264676980) | [Buy on Barnes & Noble](https://www.barnesandnoble.com/w/programming-arduino-simon-monk/1141451633)

The third edition of my best selling book on programming Arduino boards. Now covering unofficial boards like the ESP32.

![cover](/assets/images/cover_prog_arduino_3.png)

