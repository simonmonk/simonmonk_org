---
layout: "page"
permalink: /prog-pi-ed3
---

[Code](https://github.com/simonmonk/prog_pi_ed3) | [Buy on Amazon](https://www.amazon.com/Programming-Raspberry-Pi-Third-Getting/dp/126425735X) | [Buy on Barnes & Noble](https://www.barnesandnoble.com/w/programming-the-raspberry-pi-third-edition-simon-monk/1138403206)

The third edition of this popular book that will teach you Python programming using the Raspberry Pi.

![cover](/assets/images/cover_prog_pi_3.jpg)

