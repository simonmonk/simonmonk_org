---
layout: "page"
permalink: /eagle2
---

[Code](https://github.com/simonmonk/eagle) | [Buy on Amazon](https://www.amazon.com/Make-Your-Own-PCBs-EAGLE/dp/1260019195) | [Buy on Barnes & Noble](https://www.barnesandnoble.com/w/make-your-own-pcbs-with-eagle-simon-monk/1116215647)


EAGLE CAD is now part of Fusion 360.

![cover](/assets/images/cover_eagle2.jpg)

This second edition has been updated by Duncan Amos. Duncan is a very experienced PCB designer and as well as updating the book, he has added much of his wisdom to this second edition.
